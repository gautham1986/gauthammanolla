#!/bin/bash

cloudwatch-installation <<-EOF
python ./awslogs-agent-setup.py --region eu-west-1
AKIAJYVXG7B2BWCR23EQ
nQpDE/InsMBD52+ZGmfEldFbOd68ozcWBypMGKyB
eu-west-1
json
/var/log/apache2/error.log
/var/log/apache2/error.log
1
1
1
y
/var/log/apache2/access.log
/var/log/apache2/access.log
1
1
1
n
service awslogs restart
EOF