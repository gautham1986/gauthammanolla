#!/bin/bash

set -o errexit

# cloudformation stack name in us-east-1
stack_name=EdgeLambda-stage
region="us-east-1"

# This bucket need to be in us-east-1
bucket_name="stage-bolddk-lambda-artifact"

account_id="$(aws sts get-caller-identity --query Account --output text | xargs echo -n | tr -d '\r')"

# build both lambda
make dist

set -o xtrace

# deploy us-east-1-resources.yaml stack
aws --region ${region} cloudformation package \
  --template-file=us-east-1-resources.yaml \
  --output-template-file=edge-lambda.yaml \
  --s3-bucket="${bucket_name}" \

aws --region ${region} cloudformation deploy \
  --template-file=edge-lambda.yaml \
  --stack-name="${stack_name}"

# fix the lambda arn to cf_resources.yaml
viewer_request="$(aws --region ${region} cloudformation list-exports --query 'Exports[?Name==`edge-lambda-viewer-request-version-stage`].Value' --output text | xargs echo -n | tr -d '\r')"
sed -i "s/VIEWER_REQUEST_VERSION/${viewer_request}/g" cf_resources.yaml

origin_response="$(aws --region ${region} cloudformation list-exports --query 'Exports[?Name==`edge-lambda-origin-response-version-stage`].Value' --output text | xargs echo -n | tr -d '\r')"
sed -i "s/ORIGIN_RESPONSE_VERSION/${origin_response}/g" cf_resources.yaml

