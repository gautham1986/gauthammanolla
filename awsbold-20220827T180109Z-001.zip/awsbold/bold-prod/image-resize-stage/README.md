blog: https://aws.amazon.com/blogs/networking-and-content-delivery/resizing-images-with-amazon-cloudfront-lambdaedge-aws-cdn-blog/

Lambda edge doesn't support environment and need to be in us-east-1 region
So the lambda function zip need to be stored in s3 bucket that is in us-east-1

Lambda@edge is super slow to replicate with cloudfront so avoid change the
lambda functions :), otherwise be patient

Note: the EdgeLambdaRoleArn is hardcoded, please improve it
