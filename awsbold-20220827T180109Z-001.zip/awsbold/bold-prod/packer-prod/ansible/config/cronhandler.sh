#!/bin/bash
# should reside at /usr/local/bin/cronhandler.sh 
# this is called by cronhandler.service

instance_id=`curl --silent http://169.254.169.254/latest/meta-data/instance-id` #this instances instance_id
region_id=`curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/\(.*\)[a-z]/\1/'`  #this instances current reqion
#autoscaling group this current instance belongs to
ascale_group=`aws autoscaling describe-auto-scaling-instances --region $region_id --instance-ids $instance_id | jq -r '.AutoScalingInstances[]' | jq -r '.AutoScalingGroupName'`
#querying instance_id of first instance in same autoscaling groupwq
asg_first=`aws autoscaling describe-auto-scaling-groups --region $region_id --auto-scaling-group-name $ascale_group | jq -r '.AutoScalingGroups[].Instances[0].InstanceId'`

echo " this instance id : $instance_id"
echo " region id        : $region_id"
echo " ascaling group   : $ascale_group"
echo " asg first inst   : $asg_first"

if [ "$instance_id" == "$asg_first" ]; then	# This is the first instance in autoscaling group
  echo "first "
  systemctl enable cron
  systemctl start cron	
elif [ "$instance_id" != "$asg_first" ]; then	# This is not the first instance in autoscaling group
  echo "not first" 
  systemctl disable cron
  systemctl stop cron
fi
