'use strict';

const http = require('http');
const https = require('https');
const querystring = require('querystring');

const DOMParser = require('xmldom').DOMParser;
const XMLSerializer = require('xmldom').XMLSerializer;

const AWS = require('aws-sdk');
AWS.config.update({
  region: 'eu-central-1',
});
const S3 = new AWS.S3({
  signatureVersion: 'v4',
});
const Sharp = require('sharp');

// set the S3 bucket
// lambda@edge doesn't support env so hardcoded this
const BUCKET = 'static-bolddk-prod';
const BUCKET_MOBILE = 'static-mobil-bolddk-prod';

exports.handler = (event, context, callback) => {
  let response = event.Records[0].cf.response;

  console.log("cf event: ", event.Records[0].cf);
  console.log("Response status code :%s", response.status);
  console.log("Staging5 Response status code :%s", response.status);
  //check if image is not present
  if (parseInt(response.status) == 404 || parseInt(response.status) == 403) {
    console.log("response was 404");
    let request = event.Records[0].cf.request;

    // if there is no dimension attribute, just pass the response
    // DISABLED - there is never any dimensions attribute
    /*
    let params = querystring.parse(request.querystring);
    if (!params.d) {
      callback(null, response);
      return;
    }
    // read the dimension parameter value = width x height and split it by 'x'
    let dimensionMatch = params.d.split("x");
    */
    // read the required path. Ex: uri /images/100x100/webp/image.jpg
    let path = request.uri;

    // read the S3 key from the path variable.
    // Ex: path variable /images/100x100/webp/image.jpg
    let key = path.substring(1);
    console.log("key:",key);
    // parse the prefix, width, height and image name
    // Ex: key=images/200x200/webp/image.jpg
    let prefix, originalKey, match, width, height, requiredFormat, imageName, LOAD_BUCKET, SAVE_BUCKET;
    let startIndex, load_bucket, save_bucket, extension;

    try {
      match = key.match(/(.*)\/(\d*)x(\d*)\/(.*)\.(.*)/);
      prefix = match[1];
      console.log("key.match:", match);
      if(prefix == 'img/tag' || prefix == 'images/tag'){
        prefix = 'img/tag_original'
        LOAD_BUCKET = BUCKET;
        SAVE_BUCKET = BUCKET;
      }
      if(prefix == 'picture' || prefix == 'pictures' || prefix == 'images/pictures'){
        prefix = 'billeder'
        LOAD_BUCKET = BUCKET;
        SAVE_BUCKET = BUCKET_MOBILE;
      }
      width = parseInt(match[2], 10);
      height = parseInt(match[3], 10);
      // correction for jpg required for 'Sharp'
      requiredFormat = match[5] == "jpg" ? "jpeg" : match[5];
      imageName = match[4];
      extension = match[5];
      originalKey = prefix + "/" + imageName;
    }
    catch (err) {
      console.log('err',err);
      // no prefix exist for image..
      console.log("no prefix present..");
      match = key.match(/(\d*)x(\d*)\/(.*)\.(.*)/);
      width = parseInt(match[1], 10);
      height = parseInt(match[2], 10);

      // correction for jpg required for 'Sharp'
      requiredFormat = match[4] == "jpg" ? "jpeg" : match[4]; 
      imageName = match[3];
      extension = match[4];
      originalKey = imageName;
    }

    //wildcard search since extension for original file is unknown
    S3.listObjects({Bucket: LOAD_BUCKET, MaxKeys: 1, Prefix: originalKey + "."}).promise()
    .then(data_ => {
      console.log('get S3 object', data_.Contents[0].Key);
      // get the source image file
      S3.getObject({ Bucket: LOAD_BUCKET, Key: data_.Contents[0].Key }).promise()
        //if source is svg, optimize it
        .then(data => optimizeSVGimage(data.Body))
        // perform the resize operation
        // autoscale by setting null
        .then(image => Sharp(image)
          .resize(width>0?width:null, height>0?height:null)
          .background({r: 0, g: 0, b: 0, alpha: 0})
          .embed()
          .toFormat(requiredFormat)
          .toBuffer()
        )
        .then(buffer => {
          // save the resized object to S3 bucket with appropriate object key.
          S3.putObject({
              Body: buffer,
              Bucket: SAVE_BUCKET,
              ContentType: 'image/' + requiredFormat,
              CacheControl: 'max-age=604800',
              Key: key,
              StorageClass: 'STANDARD'
          }).promise()
          // even if there is exception in saving the object we send back the generated
          // image back to viewer below
          .catch(() => { console.log("Exception while writing resized image to bucket")});

          // generate a binary response with resized image
          response.status = 200;
          response.body = buffer.toString('base64');
          response.bodyEncoding = 'base64';
          response.headers['content-type'] = [{ key: 'Content-Type', value: 'image/' + requiredFormat }];
          callback(null, response);
        })
      .catch( err => {
        console.log("--> Exception while reading source image :%j",err);
      });
    });
  } // end of if block checking response statusCode
  else {
    // allow the response to pass through
    console.log("response was not 404, callback!");
    callback(null, response);
  }
};

function optimizeSVGimage(data){
  return new Promise(function(resolve, reject) {
    Sharp(data)
    .metadata()
    .then(function(metadata) {
      try{
        var doc = new DOMParser().parseFromString(data,'text/xml');
        if(doc.documentElement.tagName!='parsererror') {
          doc.documentElement.setAttribute('width',width);
          doc.documentElement.setAttribute('height',height);
          doc.documentElement.setAttribute('viewBox', '0 0 '+Math.round(metadata.width) + ' ' + Math.round(metadata.height));
          if(metadata.width < metadata.height){
            doc.documentElement.setAttribute('width',Math.round(metadata.width / metadata.height * height));
          }else{
            doc.documentElement.setAttribute('height',Math.round(metadata.height / metadata.width * width));
          }
          resolve(Buffer(new XMLSerializer().serializeToString(doc)));
        }else{
          resolve(data);
        }
      }catch(err){
        console.log('DOMParser error', err);
        console.log('Supplied data', data);
        resolve(data);
      }
    })
    .catch(error=>console.log(error));
  })
}