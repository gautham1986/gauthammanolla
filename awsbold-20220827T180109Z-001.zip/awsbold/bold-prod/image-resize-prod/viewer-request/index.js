'use strict';

const querystring = require('querystring');

// defines the allowed dimensions, default dimensions and how much variance from allowed
// dimension is allowed.

const variables = {
        allowedDimension : [ 
            //unknown height
            {w:12,h:''},
            {w:16,h:''},
            {w:20,h:''},
            {w:24,h:''},
            {w:32,h:''},
            {w:50,h:''},
            {w:60,h:''},
            {w:66,h:''},
            {w:70,h:''},
            {w:80,h:''},
            {w:98,h:''},
            {w:100,h:''},
            {w:108,h:''},
            {w:120,h:''},
            {w:138,h:''},
            {w:160,h:''},
            {w:180,h:''},
            {w:184,h:''},
            {w:260,h:''},
            {w:276,h:''},
            {w:320,h:''},
            {w:490,h:''},
            {w:512,h:''},
            {w:640,h:''},
            //unknown width
            {w:'',h:10},
            {w:'',h:12},
            {w:'',h:16},
            {w:'',h:20},
            {w:'',h:24},
            {w:'',h:32},
            {w:'',h:48},
            {w:'',h:64},
            {w:'',h:128},
            {w:'',h:180},
            {w:'',h:360},
            {w:'',h:640},
            {w:'',h:1024},
            //square
            {w:12,h:12},
            {w:14,h:14},
            {w:16,h:16},
            {w:18,h:18},
            {w:20,h:16},
            {w:20,h:20},
            {w:24,h:24},
            {w:28,h:28},
            {w:32,h:32},
            {w:40,h:40},
            {w:48,h:48},
            {w:64,h:64},
            {w:70,h:70},
            {w:72,h:72},
            {w:90,h:90},
            {w:120,h:120},
            {w:180,h:180},
            {w:360,h:360},
            {w:400,h:400},
            {w:512,h:512},
            {w:1024,h:1024},
            //letterbox
            {w:18,h:16},
            {w:70,h:46},
            {w:78,h:65},
            {w:122,h:44},
            {w:156,h:130},
            {w:160,h:105},
            {w:180,h:118},
            {w:298,h:196},
            {w:300,h:197},
            {w:320,h:210},
            {w:360,h:236},
            {w:468,h:307},
            {w:640,h:420},
            {w:960,h:630},
            //test
            {w:100,h:100}, 
            {w:200,h:200}, 
            {w:300,h:300}, 
        ],
        defaultDimension : {w:200,h:200},
        variance: 0,
        webpExtension: 'webp'
  };

exports.handler = (event, context, callback) => {
    const request = event.Records[0].cf.request;
    const headers = request.headers;
    console.log("event cf: ", event.Records[0].cf)
    console.log("Request: ", request)
    console.log("Testing build")

    // parse the querystrings key-value pairs. In our case it would be d=100x100
    const params = querystring.parse(request.querystring);

    // fetch the uri of original image
    let fwdUri = request.uri;

    // if there is no dimension attribute, just pass the request
    if(!params.d){
        callback(null, request);
        return;
    }

    // read the dimension parameter value = width x height and split it by 'x' - DISABLE d parameter
    /*
    const dimensionMatch = params.d.split("x");

    // set the width and height parameters
    let width = dimensionMatch[1];
    let height = dimensionMatch[2];

    // parse the prefix, image name and extension from the uri.
    // In our case /images/image.jpg
    */
    const match = fwdUri.match(/(.*)\/(\d*)x(\d*)\/(.*)\.(.*)/);

    let prefix = match[1];
    let width = match[2];
    let height = match[3];
    let imageName = match[4];
    let extension = match[5];

    // define variable to be set to true if requested dimension is allowed.
    let matchFound = false;

    // calculate the acceptable variance. If image dimension is 105 and is within acceptable
    // range, then in our case, the dimension would be corrected to 100.
    let variancePercent = (variables.variance/100);

    for (let dimension of variables.allowedDimension) {
        if(width == dimension.width && height == dimension.height){
            matchFound = true;
            break;
        }
    }
    // if no match is found from allowed dimension with variance then set to default
    //dimensions.
    if(!matchFound){
        width = variables.defaultDimension.w;
        height = variables.defaultDimension.h;
    }

    // read the accept header to determine if webP is supported.
    let accept = headers['accept']?headers['accept'][0].value:"";

    let url = [];
    // build the new uri to be forwarded upstream
    url.push(prefix);
    url.push(width+"x"+height);
  
    // check support for webp - DISABLE extension folder
    /*
    if (accept.includes(variables.webpExtension)) {
        url.push(variables.webpExtension);
    }
    else{
        url.push(extension);
    }
    */
    url.push(imageName+"."+extension);

    fwdUri = url.join("/");

    // final modified url is of format /images/200x200/webp/image.jpg
    // final modified url is of format /img/tag/200x200/bif.jpg
    request.uri = fwdUri;
    callback(null, request);
};
