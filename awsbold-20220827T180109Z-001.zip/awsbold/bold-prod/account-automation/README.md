New Account Basic Automation template

Bootstrap:

1. Configure aws cli
2. Run these commands below, and change BUCKET-NAME to the one you like:

```
export BUCKET=<bucket-name>

aws s3 mb s3://$BUCKET

aws s3 sync ./ s3://$BUCKET/pipeline --exclude ".git/*" --delete

aws cloudformation create-stack \
    --stack-name account-automation \
    --template-body file://account-automation-master.yaml \
    --parameters file://parameters.json \
    --capabilities CAPABILITY_NAMED_IAM
```