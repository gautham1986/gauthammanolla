this is a codepipeline to provision PoC infra for bold.dk

bootstrap:
1. configure aws cli
2. store db user and password:
```
aws ssm put-parameter --name db-user --type String --value "root"
aws ssm put-parameter --name db-password --type String --value "Passw0rd"
aws ssm put-parameter --name app-user --type String --value "app-user"
aws ssm put-parameter --name app-password --type String --value "app-password"


```
2. run these commands below, and change *bucket-name* to the one you like:
```
export BUCKET=<bucket-name>
aws s3 mb s3://$BUCKET
aws s3 sync ./ s3://$BUCKET/pipeline --exclude ".git/*" --delete
aws ec2 create-key-pair --key-name cms_ssh_key --query 'KeyMaterial' --output text > cms_ssh_key.pem
aws cloudformation create-stack \
    --stack-name pipeline \
    --template-body file://master.yaml \
    --parameters file://parameters.json \
    --capabilities CAPABILITY_IAM
```
3. store the `cms_ssh_key.pem` to parameter store and remove the local private key file:
```
aws ssm put-parameter --name cms_ssh_private_key --type SecureString --value $(cat cms_ssh_key.pem | base64 --wrap 0)
rm cms_ssh_key.pem
```
4. To share the private key with other iam users, ask them to run this command:
```
aws ssm get-parameter --name cms_ssh_private_key --with-decryption --query 'Parameter.Value' --output text | base64 -d > cms_ssh_key.pem
```
