Create Groups, Users and Policies for bold.dk

Bootstrap:

1. Configure aws cli
2. Run these commands below, and change BUCKET-NAME to the one you like:

```
export BUCKET=<bucket-name>

aws s3 mb s3://$BUCKET

aws s3 sync ./ s3://$BUCKET/iam --exclude ".git/*" --delete

aws cloudformation create-stack \
    --stack-name iam \
    --template-body file://iam-master.yaml \
    --parameters file://parameters.json \
    --capabilities CAPABILITY_NAMED_IAM
```

3. Use IAMy to Importing & Exporting AWS IAM configuration TO and From AWS

## IAMy

IAMy is a tool for dumping and loading your AWS IAM configuration into YAML files.

This allows you to use an [Infrastructure as Code](https://en.wikipedia.org/wiki/Infrastructure_as_Code) model to manage your IAM configuration, and allows you to operate configuration and change management on a higher level.

## How it works

IAMy has two subcommands.

`pull` will sync IAM users, groups and policies from AWS to YAML files

`push` will sync IAM users, groups and policies from YAML files to AWS

## Getting started

You can install IAMy on macOS with `brew install iamy`, or with the go toolchain `go get -u github.com/99designs/iamy`.

Because IAMy uses the [aws cli tool](https://aws.amazon.com/cli/), you'll want to install it first.

For configuration, IAMy uses the same [AWS environment variables](http://docs.aws.amazon.com/cli/latest/userguide/cli-environment.html) as the aws cli. You might find [aws-vault](https://github.com/99designs/aws-vault) an excellent complementary tool for managing AWS credentials.


## Example Usage

```bash
$ iamy pull

$ find .
./bolddk-np-537764775217/iam/group/BoldDevGroup1.yaml
./bolddk-np-537764775217/iam/group/MomentGroup1.yaml
./bolddk-np-537764775217/iam/group/auditors.yaml
./bolddk-np-537764775217/iam/group/EficodeSupport1.yaml
./bolddk-np-537764775217/iam/group/dev-team.yaml
./bolddk-np-537764775217/iam/group/EficodeCoreTeam1.yaml

./bolddk-np-537764775217/iam/user/TestUser31.yaml
./bolddk-np-537764775217/iam/user/TestUser11.yaml
./bolddk-np-537764775217/iam/user/TestUser41.yaml
./bolddk-np-537764775217/iam/user/TestUser21.yaml
./bolddk-np-537764775217/iam/user/TestUser22.yaml

$ touch bolddk-np-537764775217/iam/user/joey.yaml

$ iamy push
      aws iam create-user --user-name NewUser --path /
      aws iam add-user-to-group --user-name NewUser --group-name EficodeSupport1

Run 2 aws commands (0 destructive)? (y/N) y

> aws iam create-user --user-name NewUser --path /
{
    "User": {
        "Path": "/",
        "UserName": "NewUser",
        "UserId": "AIDAJKGANP5CND3HRLUGQ",
        "Arn": "arn:aws:iam::537764775217:user/NewUser",
        "CreateDate": "2018-04-27T14:35:23.337Z"
    }
}

> aws iam add-user-to-group --user-name NewUser --group-name EficodeSupport1

```

